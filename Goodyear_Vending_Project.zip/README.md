# Vend-O-Matic API Service

Vend-O-Matic is a RESTful vending machine controller designed for a Goodyear Tire franchise lobby. The service manages currency (US quarters), tracks inventory for three beverage slots, and handles transaction states including vending, refunds, and stock decrementing — all under strict hardware-style constraints.

---

## Overview

The API simulates a physical vending machine by maintaining internal state across requests, enforcing fixed pricing, and exposing machine status through custom response headers for easy hardware or client-side integration.

---

## Features

* **Strict Currency Handling**: Only accepts US quarters (value **1**) and processes coins one at a time.  
* **State Management**: Tracks machine balance and inventory across requests.  
* **Dynamic Response Headers**: Uses **X-Coins** and **X-Inventory-Remaining** for hardware-style integration.  
* **Modular Configuration**: Easily adjust pricing, slot count, and capacity via **config.js**.  
* **Minimal Dependencies**: Built with **Node.js** and **Express**, keeping the footprint lightweight and maintainable.  

---

## Setup and Execution

To run this project on a local machine (OSX, Linux, or Windows), ensure you have **Node.js** installed.

### Install Dependencies

\```bash
npm install
\```

### Start the Service

\```bash
npm start
\```

The server will initialize and listen for requests at **http://localhost:3000**.

---

## Technical Implementation

The service is built with **Node.js** and the **Express framework**, following a service-oriented design to separate HTTP handling from core business logic.

---

## Architecture

* **app.js**  
  Express server and API route handlers. Manages request parsing and response headers.

* **vending.service.js**  
  Core business logic for currency validation, balance tracking, inventory control, vending, and refunds.

* **config.js**  
  Centralized configuration for pricing, slot count, capacity, and server port.

* **package.json**  
  Project manifest containing dependencies and start scripts.

* **.gitignore**  
  Prevents tracking of **node_modules** and system-generated files.

---

## Operational Constraints

* **Inventory**: Three beverage slots, each starting with an initial capacity of **5 units**.  
* **Currency**: Only US quarters are accepted (represented as numeric value **1**).  
* **Pricing**: Each beverage costs **2 quarters ($0.50)**.  
* **Change Handling**: Any unused balance is automatically refunded after a successful vend or when a manual refund is requested.  

---

## API Specification

All interactions use the **application/json** content type.

---

## Endpoints

### PUT /
Accepts a quarter and returns the current balance in the **X-Coins** response header.

### DELETE /
Refunds all inserted quarters and resets the machine balance.

### GET /inventory
Returns an array of integers representing remaining stock in each beverage slot.

### PUT /inventory/:id
Attempts to vend a beverage from the specified slot.

* **Success**: Returns \`200 OK\`, response body \`\{"quantity": 1\}\`, and header **X-Inventory-Remaining**  
* **Insufficient Funds**: Returns \`403 Forbidden\`  
* **Out of Stock**: Returns \`404 Not Found\`

---

## Error Handling

* **403 Forbidden**: Returned when attempting to vend with fewer than **2 quarters** inserted.  
* **404 Not Found**: Returned when the selected beverage slot is empty.  

---

## Testing with cURL

You can verify machine behavior using these commands in any terminal (macOS, Linux, or Windows). The \`-i\` flag displays custom response headers.

---

### 1. Insert Currency

The machine requires **2 quarters** to purchase a drink. Insert them one at a time:

\```bash
curl -i -X PUT http://localhost:3000/ -H "Content-Type: application/json" -d '\{"coin": 1\}'
\```

**Expected:** \`204 No Content\` with header **X-Coins: 1*

---

### 2. Purchase a Beverage

Attempt to vend a drink from slot **0**:

\```bash
curl -i -X PUT http://localhost:3000/inventory/0
\```

* **Success**: \`200 OK\`, body \`\{"quantity": 1\}\`, and header **X-Inventory-Remaining**  
* **Insufficient Funds**: \`403 Forbidden\` if balance is less than **2**

---

### 3. Check Inventory

View the current stock levels for all slots:

\```bash
curl http://localhost:3000/inventory
\```

**Expected:** \`\[5, 5, 5\]\` initially, or updated values after vending.

---

### 4. Cancel and Refund

Refund all currently inserted coins:

\```bash
curl -i -X DELETE http://localhost:3000/
\```

**Expected:** \`204 No Content\` with **X-Coins** header showing the refunded amount.




