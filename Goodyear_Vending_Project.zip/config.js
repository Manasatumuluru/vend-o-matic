module.exports = {
  PORT: 3000,
  MACHINE_SPECS: {
    SLOT_COUNT: 3,
    MAX_CAPACITY: 5,
    VEND_PRICE: 2,
    QUARTER_VALUE: 1
  }
};